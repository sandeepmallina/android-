package com.example.myetp

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity_Myprofile : AppCompatActivity() {
    lateinit var filepath: Uri
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main_myprofile)



        var uploadImage: Button = findViewById(R.id.button33)

        var iv: ImageView = findViewById(R.id.imageView)

        val ip = registerForActivityResult(ActivityResultContracts.GetContent())
        {
             filepath= it!!
            iv.setImageURI(it)
        }
        uploadImage.setOnClickListener() {
            ip.launch("image/*")
        }
    }
}